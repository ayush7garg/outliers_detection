# -*- coding: utf-8 -*-
"""
Created on Sun Feb  9 18:13:20 2020

@author: Ayush Garg
"""

from outliers_detection_101703129.outliers_detection import outliers